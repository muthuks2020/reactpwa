
import React, { PropTypes } from 'react'

class Hello extends React.Component {

  render () {
    return (
      <div>
      </div>
    )
  }

}

export default Hello;
